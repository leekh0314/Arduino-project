/*
 * EXTI.h:
 * Copyright (c) 2014-2017 Rtrobot. <admin@rtrobot.org>
 *  <http://rtrobot.org>
 ***********************************************************************
 * use keil5 for arm.
 */
#ifndef __EXTI_H_
#define __EXTI_H_

#include "stm32f10x.h"
#include "main.h"

extern bool INT_Flag;

void EXTIX_Init(void);

#endif /* __EXTI_H */
